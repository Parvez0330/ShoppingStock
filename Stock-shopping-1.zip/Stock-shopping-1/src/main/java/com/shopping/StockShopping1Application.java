package com.shopping;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StockShopping1Application {

	public static void main(String[] args) {
		SpringApplication.run(StockShopping1Application.class, args);
	}

}
